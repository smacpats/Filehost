﻿Smacpats’ Track Texture pack Early Access v0.5



For dolphin or an ISO image, copy all the SZS files (everything inside of the “SZS files” folder, into /files/Race/Course and recompile your ISO.



For CTGP Revolution 1.0.3 on a real wii, copy all of the SZS files into the folder named “My Stuff” inside your CTGPR folder on your SD card. If the folder does not exist,
create it. Make sure that “My stuff” is enabled in the CTGP options menu before starting your game.


A full custom pack (with custom music and possibly UI and characters)
may come in the future. 


If you have any questions or want help, message me on Twitter @Smacpats, or on reddit /u/Smacpats111111.


This version of the pack is extreme early access. Some tracks may be broken. This might crash on a real wii (I only have tested this pack on dolphin so far).
I will do much more actual testing before even calling this an alpha version. 



Custom track wiki page- http://wiki.tockdom.com/wiki/Smacpats'_Track_Texture_Pack